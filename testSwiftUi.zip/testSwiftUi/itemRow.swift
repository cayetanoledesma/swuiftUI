//
//  itemRow.swift
//  testSwiftUi
//
//  Created by estech on 8/2/23.
//

import SwiftUI

struct itemRow: View {
    let item: MenuItem // Elemento que representa esta fila
    
    //vamos a hacer un diccionario de colores para mostrar las restricciones
    let colors:[String: Color] = ["D": .purple, "G": .black, "N": .red, "S": .blue, "V": .green]
    
    
    var body: some View {
        
        HStack{
            Image(item.thumbnailImage)
                .clipShape(Circle())
                .overlay(Circle().stroke(.blue, lineWidth: 2))
            VStack(alignment: .leading) {
                Text(item.name)
                    .font(.headline)
                Text("\(item.price) € ")
            }
            
            Spacer()
            
            ForEach(item.restrictions, id: \.self) { restriction in
                Text(restriction)
                    .font(.caption)
                    .fontWeight(.black)
                    .padding(5)
                    .background(colors[restriction, default: .black])//en el caso de que no este definida sale en negro
                    .foregroundColor(.white)
                    .clipShape(Circle())
                
            }
        }
    }
}
struct itemRow_Previews: PreviewProvider {
    static var previews: some View {
        itemRow(item: MenuItem.example)
    }
}


