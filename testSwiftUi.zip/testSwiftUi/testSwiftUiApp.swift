//
//  testSwiftUiApp.swift
//  testSwiftUi
//
//  Created by estech on 7/2/23.
//

import SwiftUI

@main
struct testSwiftUiApp: App {
    //creamos la propiedad al iniciar la aplicación , antea de crear la instancia principal
    //Crea un nuevo pedido cuando se inicia la aplicación y lo mantenemos activo independientemente de la vista que estemos mostrando, es decie lo mantiene en todas las vistas
    
    @StateObject var order = Order()
    
    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(order) //Le pasamos la instancia de Order al ContentView
        }
    }
}
