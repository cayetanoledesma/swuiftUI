//
//  ContentView.swift
//  testSwiftUi
//
//  Created by estech on 7/2/23.
//

/*
 
 Objetos observables
 
 Objetgos de entorno
 
 @Published
 
 */

import SwiftUI

struct ContentView: View {
    
    let menu = Bundle.main.decode([MenuSection].self, from: "menu.json")
    
    var body: some View {
        
        NavigationStack{
            List{
                ForEach(menu){ section in
                    Section(header: Text(section.name)){
                        ForEach(section.items){ item in
                            NavigationLink(value: item) {
                                
                                //vista //etiqueta
                                itemRow(item: item)
                            }
                        }
                    }
                }
            }
            
            .navigationTitle("Menu")
            .listStyle(GroupedListStyle())
            .navigationDestination(for: MenuItem.self){
                item in
                itemDetail(item: item)
            }
            
        }
        
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()

    }
}
