//
//  itemDetail.swift
//  testSwiftUi
//
//  Created by estech on 15/2/23.
//

import SwiftUI

struct itemDetail: View {
    
    @EnvironmentObject var order: Order  // al poner @Enviroment lo que estamos diciendole es que ya tiene un valor que coge de los demas Order instanciados en optras vistas
    
    let item: MenuItem //Almacena el item que se va a mostrar
    
    var body: some View {
        VStack{
            ZStack(alignment: .bottomTrailing){
                Image(item.mainImage)
                    .resizable()
                    .scaledToFit()
                Text("Foto: \(item.photoCredit)")
                    .padding(4)
                    .background(.black)
                    .foregroundColor(.white)
                    .offset(x: -10, y: -5)
                    .font(.caption)
                    
                
            }
           
            Text(item.description)
                .padding()
            Spacer()
        }
        .navigationTitle(item.name)
        .navigationBarTitleDisplayMode(.inline)
    }
}

struct itemDetail_Previews: PreviewProvider {
    static var previews: some View {
        NavigationStack{
            itemDetail(item: MenuItem.example)
                .environmentObject(Order())
        }
        
    }
}
